package de.goeuro.sampleapp.core.impl;

import static de.goeuro.sampleapp.utils.JSONUtils.getResults;
import static de.goeuro.sampleapp.utils.Logger.log;
import static de.goeuro.sampleapp.utils.propertyLoader.getCityURL;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;

import de.goeuro.sampleapp.core.api.CityManager;
import de.goeuro.sampleapp.core.model.Result;

public class CityManagerImpl implements CityManager{
	
	private String city;

	public CityManagerImpl(String city) {
		this.city = city;
	}

	public List<Result> getCityData() {
		String cityUrl = getCityURL(city);
		List<Result> results = null;
		try {
			results = getResults(cityUrl);
		} catch (IOException e) {
			log(Level.SEVERE, "Error while getting city data", e);
		}
		return results;
	}

	public void exportToCSV() throws FileNotFoundException {
		List<Result> results = getCityData();
		
		FileOutputStream fos = new FileOutputStream(city+".csv");
		PrintWriter pw = new PrintWriter(fos);
		
		if(results == null || results.size() == 0){
			log(Level.SEVERE, "No data found for city '"+city+"'", null);
			System.exit(-1);
		}
		
		for(Result result: results){
			pw.println(result.toCSVString(result.get_id()+"",result.getName(),result.getType(),result.getGeo_position().getLatitude(),result.getGeo_position().getLongitude()));
		}
		
		pw.flush();
		pw.close();
	}

	

}
