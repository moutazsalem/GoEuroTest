package de.goeuro.sampleapp.core.api;

import java.io.FileNotFoundException;
import java.util.List;

import de.goeuro.sampleapp.core.model.Result;

public interface CityManager {
	public List<Result> getCityData();
	public void exportToCSV() throws FileNotFoundException;
}
