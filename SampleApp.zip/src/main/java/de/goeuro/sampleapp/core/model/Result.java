package de.goeuro.sampleapp.core.model;

import java.util.Map;

public class Result {
	private Integer _id;
	private String key;
	private String name;
	private String fullName;
	private GeoPosition geo_position;
	private String iata_airport_code;
	private String type;
	private String country;
	private Integer locationId;
	private Boolean inEurope;
	private Integer countryId;
	private String countryCode;
	private Boolean coreCountry;
	private String distance;
	private Map<String, String> names;
	private Map<String, String> alternativeNames;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer getLocationId() {
		return locationId;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public Boolean getInEurope() {
		return inEurope;
	}

	public void setInEurope(Boolean inEurope) {
		this.inEurope = inEurope;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Boolean getCoreCountry() {
		return coreCountry;
	}

	public void setCoreCountry(Boolean coreCountry) {
		this.coreCountry = coreCountry;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public Map<String, String> getNames() {
		return names;
	}

	public void setNames(Map<String, String> names) {
		this.names = names;
	}

	public Map<String, String> getAlternativeNames() {
		return alternativeNames;
	}

	public void setAlternativeNames(Map<String, String> alternativeNames) {
		this.alternativeNames = alternativeNames;
	}

	public Integer get_id() {
		return _id;
	}

	public void set_id(Integer _id) {
		this._id = _id;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public GeoPosition getGeo_position() {
		return geo_position;
	}

	public void setGeo_position(GeoPosition geo_position) {
		this.geo_position = geo_position;
	}

	public String getIata_airport_code() {
		return iata_airport_code;
	}

	public void setIata_airport_code(String iata_airport_code) {
		this.iata_airport_code = iata_airport_code;
	}

	public String toCSVString(String... props) {
		String toReturn = "";
		for(String prop:props){
			toReturn+=prop+",";
		}
		if(toReturn.length()>0){
			toReturn = toReturn.substring(0, toReturn.length()-1);
		}
		return toReturn;
	}
}
