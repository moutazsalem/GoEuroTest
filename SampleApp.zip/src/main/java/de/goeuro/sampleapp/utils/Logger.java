package de.goeuro.sampleapp.utils;

import java.util.logging.Level;

public class Logger {
	
	private static java.util.logging.Logger logger = java.util.logging.Logger.getLogger("GoEuro-Sample App");
	
	public static void log(Level level, String message, Throwable thrown){
		logger.log(level, message, thrown);
	}
}
