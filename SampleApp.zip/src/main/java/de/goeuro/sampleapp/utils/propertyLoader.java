package de.goeuro.sampleapp.utils;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;

import static de.goeuro.sampleapp.utils.Logger.*;

public class propertyLoader {
	
	public static Properties properties;
	
	static{
		properties = new Properties();
		try {
			properties.load(propertyLoader.class.getResourceAsStream("app.properties"));
		} catch (IOException e) {
			log(Level.SEVERE, "Properties file \"propertyLoader.properties\" was not found", e);
		}
	}
	
	public static String getCityURL(String city){
		log(Level.INFO, "Getting the City URL", null);
		String cityUrl = properties.getProperty("CityDataURL").replace("{city_name}", city);
		log(Level.INFO, "Got the City URL: "+cityUrl, null);
		return cityUrl;
	}
}
