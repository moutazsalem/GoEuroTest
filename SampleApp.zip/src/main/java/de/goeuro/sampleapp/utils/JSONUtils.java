package de.goeuro.sampleapp.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;

import de.goeuro.sampleapp.core.model.Result;

public class JSONUtils {
	
	public static List<Result> getResults(String url) throws IOException{
		ObjectMapper mapper = new ObjectMapper();
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		URL urlWeb = new URL(url);
		URLConnection connection = urlWeb.openConnection();
		InputStream is = connection.getInputStream();
		
		int read = 0;
		byte [] buffer = new byte[1024*8];
		
		while((read=is.read(buffer))!=-1){
			outputStream.write(buffer, 0, read);
		}
		
		outputStream.flush();
		byte [] json = outputStream.toByteArray();
		
		is.close();
		outputStream.close();
		
		TypeFactory tf = TypeFactory.defaultInstance();
		
	    return mapper.readValue(json, tf.constructCollectionType(List.class, Result.class));
	}
	
}
