package de.goeuro.sampleapp;

import java.io.FileNotFoundException;
import java.util.logging.Level;

import de.goeuro.sampleapp.core.api.CityManager;
import de.goeuro.sampleapp.core.impl.CityManagerImpl;

import static de.goeuro.sampleapp.utils.Logger.*;

public class Runner {

	public static void main(String[] args) {
		
		log(Level.INFO, "GoEuro Sample Application Started", null);
		
		if(args.length!=1 || args[0].trim().length() == 0){
			log(Level.SEVERE, "No city name specified", null);
			printUsage();
			System.exit(1);
		}
		
		log(Level.INFO, "Creating CSV file for city '"+args[0]+"' ", null);
		
		CityManager cityManager = new CityManagerImpl(args[0]);
		try {
			cityManager.exportToCSV();
			log(Level.INFO, "CSV file created for city '"+args[0]+"' ", null);
		} catch (FileNotFoundException e) {
			log(Level.SEVERE, "Error while creating CSV file", e);
		}
				
		
	}

	private static void printUsage() {
		log(Level.INFO, "Example: java -jar GoEuroTest.jar \"Cairo\"", null);
	}

}
